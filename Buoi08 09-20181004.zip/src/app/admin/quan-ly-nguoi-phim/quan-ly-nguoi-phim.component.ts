import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quan-ly-nguoi-phim',
  templateUrl: './quan-ly-nguoi-phim.component.html',
  styleUrls: ['./quan-ly-nguoi-phim.component.css']
})
export class QuanLyNguoiPhimComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
