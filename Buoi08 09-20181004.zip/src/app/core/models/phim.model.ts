export interface Phim {
    Id: number;
    Name: string;
    Image: string;
}